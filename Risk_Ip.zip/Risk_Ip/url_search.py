import time

import requests
import urllib
import re
from urllib import parse
import pymysql

url='https://x.threatbook.com/v5/article?threatInfoID='
url_text='https://x.threatbook.com/v5/article?threatInfoID=40553'
db=pymysql.connect(host='localhost',user='root',password='root',db='spiders')

# 定义光标
cursor=db.cursor()

# 准备sql
sql_insert='insert into get_url(id, url) values(%s,%s)'

uid = 0
# 配置采集的网页的范围
for i in range(30000,41000):
    id=i
    url_all=url+str(id)
    response = requests.get(url_all)
    ip_translate=re.compile('(((2(5[0-5]|[0-4]\d))|[0-1]?\d{1,2})(\.((2(5[0-5]|[0-4]\d))|[0-1]?\d{1,2})){3})',re.S)
    ip_check=re.search(ip_translate,response.text)
    if ip_check!=None:
        try:
            uid=uid+1
            cursor.execute(sql_insert,(uid, url_all))
            db.commit()
            print('you got it')
        except:
            db.rollback()
            print('error')
        url_txt=open('url.txt','a')
        url_txt.write(url_all+'\n')
        # db.close()
    else:
        print(ip_check)
    time.sleep(30)

# re_request = re.compile('(((2(5[0-5]|[0-4]\d))|[0-1]?\d{1,2})(\.((2(5[0-5]|[0-4]\d))|[0-1]?\d{1,2})){3})', re.S)
# re_result = re.findall(re_request, response.text)
# for x in range(10000):
#         # print(re_result[x][0])
#     x = re_result[x][0]
#     if x!='':
#         print(x)
#         ip = open('ip.txt', 'a', encoding='utf8')
#         ip.write(x + '\n')
#     else:
#         print('1')

# response=requests.get(url)
# print(response.text)

# re_request=re.compile('(((2(5[0-5]|[0-4]\d))|[0-1]?\d{1,2})(\.((2(5[0-5]|[0-4]\d))|[0-1]?\d{1,2})){3})',re.S)
# re_result=re.findall(re_request,response.text)
# for x in range(100):
#     # print(re_result[x][0])
#     x=re_result[x][0]
#     print(x)
#     ip = open('ip.txt', 'a', encoding='utf8')
#     ip.write(x+'\n')