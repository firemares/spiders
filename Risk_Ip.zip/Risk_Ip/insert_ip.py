import pymysql



def insert_ip(url_address,ip):
    # 链接数据库
    db = pymysql.connect(host='localhost', user='root', password='root', port=3306, db='spiders', autocommit=True)
    cursor = db.cursor()

    sql_creat = 'CREATE TABLE if not exists ip_table (`id`  int NOT NULL AUTO_INCREMENT,`url_address`  varchar(255) not NULL ,`ip`  varchar(255) not NULL ,PRIMARY KEY (`id`));'
    sql_insert = 'insert ignore into ip_table(url_address, ip) values(%s,%s)'
    sql_sel='select * from ip_table where ip = %s'
    # 创建数据库
    cursor.execute(sql_creat)
    try:
        cursor.execute(sql_sel,(ip))
        if cursor.fetchone()==None:
            try:
                cursor.execute(sql_insert,(url_address,ip))
                db.commit()
                print('它的微步地址是'+url_address+'。它的ip地址是'+ip)
            except:
                db.rollback()
                print('插入失败!请联系创作者HHB')

    except:
        print('error')
    # db.close()


# insert_ip(url_address='2',ip='2')
# 执行
# cursor.execute(sql_creat)
# try:
#     cursor.execute(sql_insert,(id,url_address,ip))
#     db.commit()
#     print('插入成功')
# except:
#     db.rollback()
#     print('插入失败')
#     print(cursor.fetchall())
# 打印结果


