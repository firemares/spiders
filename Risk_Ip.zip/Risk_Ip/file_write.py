
# 写文件
def file_write(txt):
    ip_txt=open('ip.txt','a')
    ip_txt.write(txt+'\n')