import requests
import re
import time
import pymysql
import urllib
import count_num
import file_write
import get_url
import open_file
import insert_ip


#循环拿出一条地址里面的所有ip，放入txt文件中
def get_ip(parse):
    url = parse
    # response = requests.get(url)
    response = requests.get(url)
    # print(response.text)
    ip_translate = re.compile('(((2(5[0-5]|[0-4]\d))|[0-1]?\d{1,2})(\.((2(5[0-5]|[0-4]\d))|[0-1]?\d{1,2})){3})',re.S)
    ip_check = re.findall(ip_translate,response.text)
    ip_num = len(ip_check)
    for ip_id in range(ip_num):
        ip = ip_check[ip_id][0]
        if ip_check!=None:
            # 写入txt中
            file_write.file_write(ip)
            print(ip+'成功传入txt')
            # 写入mysql数据库中
            insert_ip.insert_ip(url,ip)

        else:
            print('爬取失败，请检查问题！！')
    # time.sleep(5)
    # print(ip_check)




filename='url.txt'

# 拿到所有存在风险ip的列表
url_list = open_file.open_file(filename)

# 计算所有风险url的数量
count = count_num.count_num(url_list)



# print(url_list)
for i in range(0,count):
# 循环从列表取出每一条url地址
    url_parse= get_url.get_url(i)
    print(url_parse)
    # print(type(url_parse))

# 循环从地址取出所有ip，放入txt文件中
    get_ip(url_parse)

    time.sleep(30)

print(count)
